// src/main/java/myjavaproject/Main.java

package myjavaproject;

public class Main {
    public static void main(String[] args) {
        // This file is intentionally left blank for students to add any main code if needed.
    }
}
