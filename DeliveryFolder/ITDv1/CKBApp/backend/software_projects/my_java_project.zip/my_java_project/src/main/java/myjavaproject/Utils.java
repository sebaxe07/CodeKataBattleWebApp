// src/main/java/myjavaproject/Utils.java

package myjavaproject;

public class Utils {

    // Task: Implement the following utility functions

    // Function 1: Reverse a string
    public static String reverseString(String str) {
        // TODO: Implement this function
        return null;
    }

    // Function 2: Capitalize the first letter of a string
    public static String capitalizeFirstLetter(String str) {
        // TODO: Implement this function
        return null;
    }
}
