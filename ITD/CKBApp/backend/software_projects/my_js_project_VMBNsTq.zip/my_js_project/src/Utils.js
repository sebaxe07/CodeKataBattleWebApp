// src/utils.js

// Task: Implement the following utility functions

// Function 1: Reverse a string
function reverseString(str) {
  // TODO: Implement this function
}

// Function 2: Capitalize the first letter of a string
function capitalizeFirstLetter(str) {
  // TODO: Implement this function
}

module.exports = { reverseString, capitalizeFirstLetter };
